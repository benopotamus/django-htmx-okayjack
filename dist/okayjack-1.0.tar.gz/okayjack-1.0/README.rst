https://www.writethedocs.org/guide/writing/reStructuredText/

=============================
Django Okayjack (Django+htmx)
=============================

Sometimes htmx requires you to split UI logic between the template and the views.py. E.g. form validation errors start with htmx markup in the template to hx-post the form, and then specify which templates to use to generate the response in the views.py.

Okayjack sprinkles a little bit of code on your project so you can do most/all of htmx in the template. 

********
Features
********

Using htmx-like attributes, you can: 

* specify different target, swap, etc behaviours for success and error responses. e.g. target a different part of the page when a form fails validation
* select which template, or DTL block, to use when generating the response. e.g. use a different template to generate the response when a form fails validation
* trigger different actions after a response is received, based on whether htmx reveives a success or an error response

Okayjack also adds support for PUT and PATCH to Django. It processes the response as a POST and then creates a PUT/PATCH attribute on the request, so you can do things like `MyForm(request.PATCH)`

************
Requirements
************

`django-render-block <https://github.com/clokep/django-render-block/blob/main/README.rst>`_


************
Installation
************

1. Install okayjack::

    pip install django-htmx-okayjack


2. Add okayjack and render_block to the Django project::

    INSTALLED_APPS = [
       ...
       'render_block',
       'okayjack',
    ]


   MIDDLEWARE = [
       ...
       'okayjack.middleware.OkayjackMiddleware',
   ]

3. Import ``okayjack.http`` in your ``views.py`` to use the ``HttpResponse-like`` classes

    views.py::

		from okayjack.http import HxSuccessResponse, HxErrorResponse

4. Okayjack uses an htmx extension to add the extra htmx-like attributes. Load the extension in the template in the usual way - see https://htmx.org/attributes/hx-ext/.::

	<head>
		<script defer src="{% static 'okayjack/js/htmx.ext.okayjack.js' %}"></script>
	</head>

	<body hx-ext="okayjack>

********
Examples
********

This example shows the new htmx-like attributes being used to specify which DTL block to use for a "success" response, and which to use for an "error" response (e.g. form failed validaiton).

The DTL blocks can be in any file - even in the same file as the originating htmx, as is the case in this example.

You can also just reference a template file without the block part (the part after the colon).

store.html::

    {% block title_form %}
       <form 
           hx-post="/store"
           hx-success-target="h1"
           hx-success-swap="outerHTML"
           hx-success-block="this-example-file.html:title_success"
           hx-error-block="this-example-file.html:title_form">
    
               <input id="title" name="title" type="text" {% if form.title.errors % class="error"{% endif %}>
               {% if form.title.errors %}
                   <div class='error'>{{ form.title.errors }}</div>
               {% endif %}
               <button type="submit">Submit</button>
    
       </form>
    {% endblock %}
    
    <template>
       {% block title_success %}
           <h1>{{ title }}</h1>
       {% endblock %}
    </template>


Given the above HTML, in the corresponding Django view, we now only have to do the following to handle both success and error variations.

views.py::

   def title(request, question_id):
       form = TitleForm(request.POST)
       if form.is_valid():
           form.save()
           return HxSuccessResponse(request, {'form': form})
       return HxErrorResponse(request, {'form': form})

As you can see, all of the UI logic about which template to use for success and failures has been moved to the template, leaving the views.py to just specify whether the response should be treated as a success or error.

API
===

.. _htmx-extension-1:

htmx extension
--------------

Supports all htmx response headers https://htmx.org/reference/#response_headers.

You can use any combination of: 

* ``hx-*`` attributes. E.g. ``hx-target="..."``
* ``hx-success-*`` attributes. E.g. ``hx-success-target="..."``. Used when Django returns a ``HxSuccessResponse``.
* ``hx-error-*`` attributes. E.g. ``hx-error-target="..."``. Used when Django returns a ``HxErrorResponse``.

htmx will use the values of ``hx-*`` unless there is a ``hx-success-*``
or ``hx-error-*`` value (for a success or error response respectively).

The ``*`` in ``hx-success-*`` and ``hx-error-*`` attributes can be any
of the following.

-  location
-  push-url
-  redirect
-  refresh
-  replace-url
-  swap
-  target
-  trigger-after-receive
-  trigger-after-settle
-  trigger-after-swap
-  block

``trigger-after-receive`` isn’t a normal htmx attribute. It sets the ``HX-Trigger`` response header. It had to be renamed so it doesn’t conflict with ``hx-trigger`` for triggering the request itself 🤷

``block`` is the path to a template and optional template block to use when generating the HTML response. E.g. ``hx-block="base/home.html:welcome_block"`` or ``hx-success-block="base/home.html:new_item"``

Blocks are regular Django template blocks. E.g.

``{% block welcome_block %}<p>some html here</p>{% endblock }``

HttpResponse classes (main)
---------------------------

The main response classes you will use are

HxResponse(request[, context, block=None, swap=None, trigger-after-receive=None, trigger_after_settle=None, trigger_after_swap=None])
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Creates a TemplateResponse-like object using django-render-block and
htmx header functions. Its main purpose is to make it easy to specify -
on the server side - what htmx should do with a response.

Automatically gets the block name from ``HX-Block`` header, or it can be
specified as a kwarg. The format of block should be
``path/to/template.html:block_name``

``HxResponse(request, { 'form': form })``

Supports optional kwargs

``HxResponse(request, { 'form': form, trigger-after-receive='do-this-when-response-is-received'})``

HxSuccessResponse(request[, context, block=None, swap=None, trigger-after-receive=None, trigger_after_settle=None, trigger_after_swap=None])
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Creating a ‘success’ ``HxResponse``. The response will use any
``hx-success-*`` attributes specified in the request markup.

HxErrorResponse(request[, context, block=None, swap=None, trigger-after-receive=None, trigger_after_settle=None, trigger_after_swap=None])
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Creates an ‘error’ HxResponse. The response will use any ``hx-error-*``
attributes specified in the request markup.

HttpResponse classes (extra)
----------------------------

Some extra response classes for when you don’t intend to swap some new
HTML into the page.

HxDoNothing
~~~~~~~~~~~

A ``HttpResponse`` that tells htmx to do nothing

``HxDoNothing()``

HxRedirect
~~~~~~~~~~

A ``HttpResponse`` that tells htmx to do a client side redirect to the
provided URL

``HxRedirect(reverse('home'))``

HxRefresh
~~~~~~~~~

A ``HttpResponse`` that tells htmx to refresh the page

``HxRefresh()``

HxTrigger(trigger_after_receive=None, trigger_after_swap=None, trigger_after_settle=None)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A ``HttpResponse`` that tells htmx to trigger an event - and do nothing
else. https://htmx.org/headers/hx-trigger/

trigger: the name of the event to trigger. Can also be JSON string,
which allows for triggering multiple events and/or passing data for the
event

``HxTrigger('close-modal')``

BlockResponse(block)
~~~~~~~~~~~~~~~~~~~~

Creates a ``TemplateResponse-like`` object using django-render-block to
render just a block in a template The format of block is
``template_path/template_name:block_name``.

``BlockResponse('base/home.html:welcome_block')``